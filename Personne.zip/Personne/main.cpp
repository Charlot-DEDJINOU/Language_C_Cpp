#include <iostream>
#include <string>
#include "Personne.h"

using namespace std;

int main()
{
    string nom ,date;
    char sexe ;
    double taille ;
    bool estMalade ;

    cout << "Entrez vos informations " << endl;
    cin>>nom>>date>>estMalade>>sexe>>taille ;

    return 0;
}
